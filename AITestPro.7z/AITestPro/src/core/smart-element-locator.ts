import { Page, Locator } from '@playwright/test';

export class SmartElementLocator {
    private page: Page;
    private elementPatterns: Map<string, string[]>;

    constructor(page: Page) {
        this.page = page;
        this.initializePatterns();
    }

    private initializePatterns(): void {
        this.elementPatterns = new Map([
            ['username input', ['#user-name', '[data-test="username"]']],
            ['password input', ['#password', '[data-test="password"]']],
            ['login button', ['#login-button', '[data-test="login-button"]']],
            ['error message', ['[data-test="error"]', '.error-message']],
            ['products title', ['.title', '[data-test="title"]']],
            ['shopping cart', ['.shopping_cart_link', '[data-test="shopping-cart-link"]']],
            ['menu button', ['#react-burger-menu-btn', '.bm-burger-button']],
            ['checkout button', ['[data-test="checkout"]', '#checkout']],
            ['continue button', ['[data-test="continue"]', '#continue']],
            ['finish button', ['[data-test="finish"]', '#finish']]
        ]);
    }

    async findElement(description: string): Promise<Locator> {
        try {
            const patterns = this.elementPatterns.get(description.toLowerCase()) || [];
            
            for (const pattern of patterns) {
                try {
                    const locator = this.page.locator(pattern);
                    if (await locator.isVisible({ timeout: 5000 })) {
                        console.log(`✅ Found element using pattern: ${pattern}`);
                        return locator;
                    }
                } catch (error) {
                    continue;
                }
            }
            return await this.aiElementDetection(description);
        } catch (error) {
            console.error(`❌ Failed to locate element: ${description}`, error);
            throw new Error(`Element not found: ${description}`);
        }
    }

    private async aiElementDetection(description: string): Promise<Locator> {
        console.log(`🤖 Using AI detection for: ${description}`);
        
        const possibleSelectors = [
            `button:has-text("${description}")`,
            `a:has-text("${description}")`,
            `input[placeholder*="${description}"]`,
            `[aria-label*="${description}"]`,
            `[class*="${description.toLowerCase().replace(/\s+/g, '-')}"]`,
            `[data-test*="${description.toLowerCase().replace(/\s+/g, '-')}"]`,
            `[id*="${description.toLowerCase().replace(/\s+/g, '-')}"]`,
            `text=${description}`
        ];

        for (const selector of possibleSelectors) {
            try {
                const locator = this.page.locator(selector);
                const count = await locator.count();
                if (count > 0) {
                    console.log(`✅ AI found element using: ${selector}`);
                    return locator.first();
                }
            } catch (error) {
                continue;
            }
        }
        
        throw new Error(`❌ AI could not locate element: ${description}`);
    }

    async addCustomPattern(description: string, selectors: string[]): Promise<void> {
        this.elementPatterns.set(description.toLowerCase(), selectors);
    }

    getPatterns(): Map<string, string[]> {
        return new Map(this.elementPatterns);
    }
}