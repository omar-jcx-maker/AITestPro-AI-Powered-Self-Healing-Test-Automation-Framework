import { BasePage } from '../core/base-page';
import { Page, expect } from '@playwright/test';

export class ProductsPage extends BasePage {
    constructor(page: Page) {
        super(page);
    }

    async getPageTitle(): Promise<string> {
        const titleElement = await this.findElement('products title');
        const text = await titleElement.textContent();
        return text || '';
    }

    async addProductToCart(productName: string): Promise<void> {
        const normalizedName = productName.toLowerCase().replace(/\s+/g, '-');
        const addToCartButton = this.page.locator(`[data-test="add-to-cart-${normalizedName}"]`);
        
        try {
            await addToCartButton.click();
            await this.takeSmartScreenshot(`added-${normalizedName}-to-cart`);
        } catch (error) {
            throw new Error(`Failed to add product ${productName} to cart`);
        }
    }

    async goToCart(): Promise<void> {
        const cartIcon = await this.findElement('shopping cart');
        await cartIcon.click();
    }

    async verifyProductAdded(): Promise<void> {
        const cartBadge = this.page.locator('.shopping_cart_badge');
        await expect(cartBadge).toBeVisible();
    }

    async getProductCount(): Promise<number> {
        const productItems = this.page.locator('[data-test="inventory-item"]');
        return await productItems.count();
    }

    async sortProducts(option: string): Promise<void> {
        const sortDropdown = this.page.locator('[data-test="product-sort-container"]');
        await sortDropdown.selectOption(option);
    }
}