import { Page, Locator } from '@playwright/test';

export class SelfHealingEngine {
    private page: Page;
    private healingAttempts: Map<string, number> = new Map();
    private maxAttempts: number = 3;

    constructor(page: Page) {
        this.page = page;
    }

    async healElement(originalSelector: string, description: string): Promise<Locator | null> {
        const attemptKey = `${originalSelector}-${description}`;
        const attempts = this.healingAttempts.get(attemptKey) || 0;
        
        if (attempts >= this.maxAttempts) {
            console.log(`❌ Max healing attempts (${this.maxAttempts}) reached for: ${description}`);
            return null;
        }

        console.log(`🔄 Healing element: ${description}, attempt: ${attempts + 1}`);
        this.healingAttempts.set(attemptKey, attempts + 1);

        const healingStrategies = [
            () => this.tryAlternativeSelectors(description),
            () => this.waitAndRetry(originalSelector),
            () => this.refreshPageAndRetry(originalSelector),
            () => this.tryXPathVariations(description),
            () => this.tryPartialTextMatch(description)
        ];

        for (const strategy of healingStrategies) {
            try {
                const result = await strategy();
                if (result) {
                    console.log(`✅ Healing successful for: ${description}`);
                    return result;
                }
            } catch (error) {
                console.log(`⚠️ Healing strategy failed: ${error}`);
                continue;
            }
        }

        return null;
    }

    private async tryAlternativeSelectors(description: string): Promise<Locator | null> {
        const alternativeSelectors = this.generateAlternativeSelectors(description);
        
        for (const selector of alternativeSelectors) {
            try {
                const element = this.page.locator(selector);
                if (await element.isVisible({ timeout: 2000 })) {
                    return element;
                }
            } catch (error) {
                continue;
            }
        }
        return null;
    }

    private async waitAndRetry(selector: string): Promise<Locator | null> {
        await this.page.waitForTimeout(3000);
        const element = this.page.locator(selector);
        return (await element.isVisible()) ? element : null;
    }

    private async refreshPageAndRetry(selector: string): Promise<Locator | null> {
        await this.page.reload();
        await this.page.waitForLoadState('networkidle');
        const element = this.page.locator(selector);
        return (await element.isVisible()) ? element : null;
    }

    private async tryXPathVariations(description: string): Promise<Locator | null> {
        const xpathVariations = [
            `//*[contains(text(), '${description}')]`,
            `//*[contains(@*, '${description}')]`,
            `//button[contains(., '${description}')]`,
            `//a[contains(., '${description}')]`,
            `//input[contains(@placeholder, '${description}')]`
        ];

        for (const xpath of xpathVariations) {
            try {
                const element = this.page.locator(`xpath=${xpath}`);
                if (await element.isVisible({ timeout: 1000 })) {
                    return element;
                }
            } catch (error) {
                continue;
            }
        }
        return null;
    }

    private async tryPartialTextMatch(description: string): Promise<Locator | null> {
        const words = description.split(' ');
        for (const word of words) {
            if (word.length > 2) {
                try {
                    const element = this.page.locator(`text=${word}`);
                    if (await element.isVisible({ timeout: 1000 })) {
                        return element;
                    }
                } catch (error) {
                    continue;
                }
            }
        }
        return null;
    }

    private generateAlternativeSelectors(description: string): string[] {
        const baseName = description.toLowerCase().replace(/\s+/g, '-');
        const alternatives: string[] = [];
        
        // Data attributes
        alternatives.push(`[data-test="${baseName}"]`);
        alternatives.push(`[data-testid="${baseName}"]`);
        alternatives.push(`[data-qa="${baseName}"]`);
        
        // ARIA attributes
        alternatives.push(`[aria-label="${description}"]`);
        alternatives.push(`[aria-labelledby*="${baseName}"]`);
        
        // Class and ID based
        alternatives.push(`.${baseName}`);
        alternatives.push(`#${baseName}`);
        alternatives.push(`[class*="${baseName}"]`);
        alternatives.push(`[id*="${baseName}"]`);
        
        // Role based
        alternatives.push(`[role="button"]:has-text("${description}")`);
        alternatives.push(`button:has-text("${description}")`);
        alternatives.push(`a:has-text("${description}")`);
        alternatives.push(`input[value="${description}"]`);
        
        return alternatives.filter(selector => selector && selector.length > 0);
    }

    resetHealingAttempts(): void {
        this.healingAttempts.clear();
        console.log('🔄 Healing attempts reset');
    }

    getHealingStats(): Map<string, number> {
        return new Map(this.healingAttempts);
    }
}