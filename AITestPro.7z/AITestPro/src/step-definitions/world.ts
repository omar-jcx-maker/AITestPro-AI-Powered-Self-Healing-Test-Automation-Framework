import { setWorldConstructor, World, IWorldOptions } from '@cucumber/cucumber';
import { Browser, BrowserContext, Page, chromium } from 'playwright';

export interface OurWorldParameters {
    headed: boolean;
}

export interface CustomWorld extends World {
    browser: Browser | null;
    context: BrowserContext | null;
    page: Page | null;
    loginPage: any;
    productsPage: any;
    cartPage: any;
}

export class OurWorld implements CustomWorld {
    public browser: Browser | null = null;
    public context: BrowserContext | null = null;
    public page: Page | null = null;
    public loginPage: any = null;
    public productsPage: any = null;
    public cartPage: any = null;

    constructor(public parameters: OurWorldParameters, public options: IWorldOptions) {}

    async init(): Promise<void> {
        this.browser = await chromium.launch({ 
            headless: !this.parameters.headed,
            args: ['--no-sandbox', '--disable-dev-shm-usage']
        });
        this.context = await this.browser.newContext({
            viewport: { width: 1280, height: 720 },
            ignoreHTTPSErrors: true
        });
        this.page = await this.context.newPage();
    }

    async close(): Promise<void> {
        if (this.context) {
            await this.context.close();
        }
        if (this.browser) {
            await this.browser.close();
        }
    }
}

setWorldConstructor(OurWorld);