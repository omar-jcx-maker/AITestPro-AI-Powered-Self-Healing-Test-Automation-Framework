import { BasePage } from '../core/base-page';
import { Page, expect } from '@playwright/test';

export class CartPage extends BasePage {
    constructor(page: Page) {
        super(page);
    }

    async navigateToCart(): Promise<void> {
        const cartIcon = await this.findElement('shopping cart');
        await cartIcon.click();
        await this.page.waitForURL('**/cart.html');
    }

    async getCartItemsCount(): Promise<number> {
        const cartBadge = this.page.locator('.shopping_cart_badge');
        if (await cartBadge.isVisible()) {
            const countText = await cartBadge.textContent();
            return parseInt(countText || '0');
        }
        return 0;
    }

    async removeItemFromCart(itemName: string): Promise<void> {
        const removeButton = this.page.locator(`[data-test="remove-${itemName.toLowerCase().replace(/\s+/g, '-')}"]`);
        await removeButton.click();
        await this.takeSmartScreenshot(`removed-${itemName}-from-cart`);
    }

    async proceedToCheckout(): Promise<void> {
        const checkoutButton = await this.findElement('checkout button');
        await checkoutButton.click();
    }

    async verifyCartIsEmpty(): Promise<void> {
        const cartItem = this.page.locator('.cart_item');
        await expect(cartItem).toHaveCount(0);
    }

    async verifyItemInCart(itemName: string): Promise<void> {
        const itemElement = this.page.locator(`[data-test="inventory-item"]:has-text("${itemName}")`);
        await expect(itemElement).toBeVisible();
    }

    async getCartItemNames(): Promise<string[]> {
        const itemNames: string[] = [];
        const items = this.page.locator('[data-test="inventory-item-name"]');
        const count = await items.count();
        
        for (let i = 0; i < count; i++) {
            const name = await items.nth(i).textContent();
            if (name) itemNames.push(name);
        }
        
        return itemNames;
    }
}