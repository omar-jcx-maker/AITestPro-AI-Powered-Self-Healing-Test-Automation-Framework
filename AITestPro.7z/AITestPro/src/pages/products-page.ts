import { BasePage } from '../core/base-page';
import { Page, expect } from '@playwright/test';

export class ProductsPage extends BasePage {
    constructor(page: Page) {
        super(page);
    }

    async getPageTitle(): Promise<string> {
        const titleElement = await this.findElement('products title');
        return await titleElement.textContent() || '';
    }

    async addProductToCart(productName: string): Promise<void> {
        const addToCartButton = this.page.locator(`[data-test="add-to-cart-${productName.toLowerCase().replace(/\s+/g, '-')}"]`);
        await addToCartButton.click();
        await this.takeSmartScreenshot(`added-${productName}-to-cart`);
    }

    async goToCart(): Promise<void> {
        const cartIcon = await this.findElement('shopping cart');
        await cartIcon.click();
    }

    async verifyProductAdded(): Promise<void> {
        const cartBadge = this.page.locator('.shopping_cart_badge');
        await expect(cartBadge).toBeVisible();
    }
}