import { BasePage } from '../core/base-page';
import { Page, expect } from '@playwright/test';

export class LoginPage extends BasePage {
    constructor(page: Page) {
        super(page);
    }

    async navigateToLogin(): Promise<void> {
        await this.page.goto('https://www.saucedemo.com/');
        await this.waitForNetworkIdle();
    }

    async login(username: string, password: string): Promise<void> {
        const usernameField = await this.findElement('username input');
        const passwordField = await this.findElement('password input');
        const loginButton = await this.findElement('login button');

        await usernameField.fill(username);
        await passwordField.fill(password);
        await loginButton.click();
        
        await this.takeSmartScreenshot('after-login');
    }

    async verifySuccessfulLogin(): Promise<void> {
        await this.page.waitForURL('**/inventory.html');
        const title = await this.page.locator('.title').textContent();
        expect(title).toContain('Products');
    }

    async verifyLoginError(): Promise<void> {
        try {
            const errorElement = await this.findElement('error message');
            await expect(errorElement).toBeVisible();
        } catch (error) {
            throw new Error('Login error message not found');
        }
    }

    async isLoginPageLoaded(): Promise<boolean> {
        try {
            const loginButton = await this.findElement('login button');
            return await loginButton.isVisible();
        } catch (error) {
            return false;
        }
    }
}