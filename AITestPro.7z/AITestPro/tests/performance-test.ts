import { test, expect } from '@playwright/test';
import { PerformanceMonitor } from '../src/utils/performance-monitor';

test.describe('Performance Tests', () => {
    let performanceMonitor: PerformanceMonitor;

    test.beforeEach(() => {
        performanceMonitor = new PerformanceMonitor();
    });

    test('Page load performance', async ({ page }) => {
        performanceMonitor.startMeasurement('page_load');
        
        await page.goto('https://www.saucedemo.com/');
        
        performanceMonitor.endMeasurement('page_load');
        const metrics = performanceMonitor.getMetrics();
        
        expect(metrics.page_load.duration).toBeLessThan(3000);
        performanceMonitor.logMetrics();
    });

    test('Login performance', async ({ page }) => {
        await page.goto('https://www.saucedemo.com/');
        
        performanceMonitor.startMeasurement('login_process');
        
        await page.fill('#user-name', 'standard_user');
        await page.fill('#password', 'secret_sauce');
        await page.click('#login-button');
        await page.waitForURL('**/inventory.html');
        
        performanceMonitor.endMeasurement('login_process');
        const metrics = performanceMonitor.getMetrics();
        
        expect(metrics.login_process.duration).toBeLessThan(5000);
        
        const performanceScore = performanceMonitor.getPerformanceScore();
        console.log(`🏆 Performance Score: ${performanceScore.toFixed(2)}/100`);
        
        expect(performanceScore).toBeGreaterThan(80);
    });

    test('Memory usage check', async ({ page }) => {
        await page.goto('https://www.saucedemo.com/');
        
        const memoryUsage = await page.evaluate(() => {
            if (window.performance && (performance as any).memory) {
                return (performance as any).memory.usedJSHeapSize;
            }
            return null;
        });

        if (memoryUsage) {
            const memoryMB = Math.round(memoryUsage / 1024 / 1024);
            console.log(`💾 Memory usage: ${memoryMB}MB`);
            expect(memoryUsage).toBeLessThan(100 * 1024 * 1024); // Less than 100MB
        }
    });

    test('Multiple operations performance', async ({ page }) => {
        await page.goto('https://www.saucedemo.com/');
        
        // Measure multiple operations
        await performanceMonitor.measureAction('login', async () => {
            await page.fill('#user-name', 'standard_user');
            await page.fill('#password', 'secret_sauce');
            await page.click('#login-button');
            await page.waitForURL('**/inventory.html');
        });

        await performanceMonitor.measureAction('add_to_cart', async () => {
            await page.click('[data-test="add-to-cart-sauce-labs-backpack"]');
        });

        await performanceMonitor.measureAction('navigation', async () => {
            await page.click('.shopping_cart_link');
            await page.waitForURL('**/cart.html');
        });

        performanceMonitor.logMetrics();
        
        const metrics = performanceMonitor.getMetrics();
        expect(metrics.login.duration).toBeLessThan(5000);
        expect(metrics.add_to_cart.duration).toBeLessThan(2000);
        expect(metrics.navigation.duration).toBeLessThan(3000);
    });
});