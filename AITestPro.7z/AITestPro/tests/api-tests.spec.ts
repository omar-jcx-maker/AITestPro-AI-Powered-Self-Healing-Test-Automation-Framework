import { test, expect } from '@playwright/test';
import axios from 'axios';

test.describe('API Tests', () => {
    test('GET products API should return data', async () => {
        const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
        
        expect(response.status).toBe(200);
        expect(Array.isArray(response.data)).toBe(true);
        expect(response.data.length).toBeGreaterThan(0);
        
        // Verify response structure
        const firstItem = response.data[0];
        expect(firstItem).toHaveProperty('id');
        expect(firstItem).toHaveProperty('title');
        expect(firstItem).toHaveProperty('body');
    });

    test('Security test - Input validation', async () => {
        const maliciousInput = "' OR '1'='1";
        
        try {
            const response = await axios.get(`https://jsonplaceholder.typicode.com/posts?search=${encodeURIComponent(maliciousInput)}`);
            expect(response.status).not.toBe(500);
        } catch (error: any) {
            if (error.response) {
                expect(error.response.status).not.toBe(500);
            }
        }
    });

    test('POST create resource', async () => {
        const testData = {
            title: 'Test Title',
            body: 'Test Body',
            userId: 1
        };

        const response = await axios.post('https://jsonplaceholder.typicode.com/posts', testData);

        expect(response.status).toBe(201);
        expect(response.data).toHaveProperty('id');
        expect(response.data.title).toBe(testData.title);
        expect(response.data.body).toBe(testData.body);
        expect(response.data.userId).toBe(testData.userId);
    });

    test('PUT update resource', async () => {
        const updateData = {
            id: 1,
            title: 'Updated Title',
            body: 'Updated Body',
            userId: 1
        };

        const response = await axios.put('https://jsonplaceholder.typicode.com/posts/1', updateData);

        expect(response.status).toBe(200);
        expect(response.data.title).toBe(updateData.title);
        expect(response.data.body).toBe(updateData.body);
    });

    test('DELETE resource', async () => {
        const response = await axios.delete('https://jsonplaceholder.typicode.com/posts/1');
        expect(response.status).toBe(200);
    });
});