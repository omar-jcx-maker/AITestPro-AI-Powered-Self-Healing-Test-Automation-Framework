import { writeFileSync, mkdirSync, existsSync } from 'fs';
import { join } from 'path';

export class ReportHelper {
    static generateTestSummary(results: any): void {
        const summary = {
            totalTests: results.total,
            passed: results.passed,
            failed: results.failed,
            executionTime: results.duration,
            timestamp: new Date().toISOString(),
            aiHealingAttempts: this.getHealingStats()
        };

        const reportsDir = join(process.cwd(), 'reports');
        if (!existsSync(reportsDir)) {
            mkdirSync(reportsDir, { recursive: true });
        }

        writeFileSync(
            join(reportsDir, 'test-summary.json'),
            JSON.stringify(summary, null, 2)
        );

        console.log('📄 Test summary generated:', join(reportsDir, 'test-summary.json'));
    }

    static saveScreenshotData(screenshotPath: string, metadata: any): void {
        const screenshotData = {
            path: screenshotPath,
            timestamp: new Date().toISOString(),
            metadata: metadata
        };

        const screenshotsDir = join(process.cwd(), 'reports', 'screenshot-metadata');
        if (!existsSync(screenshotsDir)) {
            mkdirSync(screenshotsDir, { recursive: true });
        }

        writeFileSync(
            join(screenshotsDir, `screenshot-${Date.now()}.json`),
            JSON.stringify(screenshotData, null, 2)
        );
    }

    private static getHealingStats(): any {
        // This would typically get stats from the SelfHealingEngine
        return {
            totalHealingAttempts: 0,
            successfulHeals: 0,
            failedHeals: 0
        };
    }

    static generatePerformanceReport(metrics: any): void {
        const performanceReport = {
            pageLoadTime: metrics.page_load?.duration || 0,
            loginProcessTime: metrics.login_process?.duration || 0,
            timestamp: new Date().toISOString(),
            recommendations: this.generatePerformanceRecommendations(metrics)
        };

        const reportsDir = join(process.cwd(), 'reports');
        if (!existsSync(reportsDir)) {
            mkdirSync(reportsDir, { recursive: true });
        }

        writeFileSync(
            join(reportsDir, 'performance-report.json'),
            JSON.stringify(performanceReport, null, 2)
        );
    }

    private static generatePerformanceRecommendations(metrics: any): string[] {
        const recommendations: string[] = [];
        
        if (metrics.page_load?.duration > 3000) {
            recommendations.push('Optimize page load time - consider lazy loading');
        }
        
        if (metrics.login_process?.duration > 5000) {
            recommendations.push('Optimize login process - check API response times');
        }

        return recommendations;
    }
}