
```typescript
import { Page, Locator } from '@playwright/test';
import { SmartElementLocator } from '../ai-components/element-detector';

export abstract class BasePage {
    protected page: Page;
    protected smartLocator: SmartElementLocator;

    constructor(page: Page) {
        this.page = page;
        this.smartLocator = new SmartElementLocator(page);
    }

    protected async findElement(description: string): Promise<Locator> {
        try {
            return await this.smartLocator.findElement(description);
        } catch (error) {
            console.error(`Element not found: ${description}`, error);
            throw new Error(`Element not found: ${description}`);
        }
    }

    protected async takeSmartScreenshot(name: string): Promise<void> {
        await this.page.screenshot({ 
            path: `screenshots/${name}-${Date.now()}.png`,
            fullPage: true 
        });
    }

    protected async smartWait(ms: number = 5000): Promise<void> {
        await this.page.waitForTimeout(ms);
    }

    protected async waitForNetworkIdle(): Promise<void> {
        await this.page.waitForLoadState('networkidle');
    }

    protected async waitForDOMContentLoaded(): Promise<void> {
        await this.page.waitForLoadState('domcontentloaded');
    }
}