import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { OurWorld } from './world';
import { LoginPage } from '../pages/login-page';
import { ProductsPage } from '../pages/products-page';
import { CartPage } from '../pages/cart-page';

Given('I am on the login page', async function (this: OurWorld) {
    await this.init();
    this.loginPage = new LoginPage(this.page!);
    await this.loginPage.navigateToLogin();
});

When('I login with {string} and {string}', async function (this: OurWorld, username: string, password: string) {
    await this.loginPage!.login(username, password);
});

Then('I should see the products page', async function (this: OurWorld) {
    this.productsPage = new ProductsPage(this.page!);
    const title = await this.productsPage.getPageTitle();
    expect(title).toContain('Products');
});

When('I add {string} to the cart', async function (this: OurWorld, productName: string) {
    await this.productsPage!.addProductToCart(productName);
});

Then('I should see the product in cart', async function (this: OurWorld) {
    await this.productsPage!.verifyProductAdded();
});

When('I go to the cart', async function (this: OurWorld) {
    this.cartPage = new CartPage(this.page!);
    await this.cartPage.navigateToCart();
});

Then('I should see {int} items in the cart', async function (this: OurWorld, expectedCount: number) {
    const actualCount = await this.cartPage!.getCartItemsCount();
    expect(actualCount).toBe(expectedCount);
});

Then('I should see {string} in the cart', async function (this: OurWorld, productName: string) {
    await this.cartPage!.verifyItemInCart(productName);
});

When('I remove {string} from the cart', async function (this: OurWorld, productName: string) {
    await this.cartPage!.removeItemFromCart(productName);
});

Then('the cart should be empty', async function (this: OurWorld) {
    await this.cartPage!.verifyCartIsEmpty();
});

Then('I close the browser', async function (this: OurWorld) {
    await this.close();
});