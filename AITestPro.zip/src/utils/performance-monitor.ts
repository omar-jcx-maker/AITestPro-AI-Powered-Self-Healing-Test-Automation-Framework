export class PerformanceMonitor {
    private startTime: number = 0;
    private metrics: any = {};

    startMeasurement(name: string): void {
        this.metrics[name] = { start: Date.now() };
        console.log(`⏱️ Starting measurement: ${name}`);
    }

    endMeasurement(name: string): void {
        if (this.metrics[name]) {
            this.metrics[name].end = Date.now();
            this.metrics[name].duration = this.metrics[name].end - this.metrics[name].start;
            console.log(`⏱️ Measurement ${name} completed: ${this.metrics[name].duration}ms`);
        }
    }

    getMetrics(): any {
        return this.metrics;
    }

    logMetrics(): void {
        console.log('📊 Performance Metrics:');
        Object.keys(this.metrics).forEach(key => {
            console.log(`  ${key}: ${this.metrics[key].duration}ms`);
        });
    }

    async measurePageLoad(page: any): Promise<number> {
        this.startMeasurement('page_load');
        await page.goto('https://www.saucedemo.com/');
        this.endMeasurement('page_load');
        return this.metrics.page_load.duration;
    }

    async measureAction(name: string, action: () => Promise<void>): Promise<number> {
        this.startMeasurement(name);
        await action();
        this.endMeasurement(name);
        return this.metrics[name].duration;
    }

    getPerformanceScore(): number {
        const durations = Object.values(this.metrics).map((metric: any) => metric.duration);
        const averageDuration = durations.reduce((a: number, b: number) => a + b, 0) / durations.length;
        
        // Lower duration = higher score (max 100)
        return Math.max(0, 100 - (averageDuration / 100));
    }
}